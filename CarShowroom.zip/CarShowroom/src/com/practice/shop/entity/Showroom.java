package com.practice.shop.entity;

import java.util.List;

public class Showroom 
{
	private int id;
	private String name;
	
	private List<Car> cars;

	public Showroom() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Showroom(int id, String name, List<Car> cars) {
		super();
		this.id = id;
		this.name = name;
		this.cars = cars;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Car> getCars() {
		return cars;
	}

	public void setCars(List<Car> cars) {
		this.cars = cars;
	}
}
